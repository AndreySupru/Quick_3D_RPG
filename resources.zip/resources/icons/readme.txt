Free asset from https://game-icons.net/
