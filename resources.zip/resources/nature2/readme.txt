Free asset from http://quaternius.com/
