Free asset from https://www.mixamo.com/.
